<?php
include_once('Calendar.php');
$calendar = new Calendar(date("Y-m-d"));

$results        =$this->getData($this->tableEvent,"ORDER BY id desc");

 foreach($results as $k=>$v) {
	// echo $v['name'];
	 $date=date('Y-m-d', strtotime($v['startDate']));
	// echo $date;
	$calendar->add_event($v['name'],  $date, 1, 'Red'); 
 }

?>

	    <nav class="navtop">
	    	<div>
	    		<h1>Event Calendar</h1>
	    	</div>
	    </nav>
		<div class="content home">
			<?=$calendar?>
</div>
<div class="show-pop form-popup" >
   <form name="form" id="form" method="post" action="">
        <table cellspacing="0" class="wp-list-table widefat fixed posts">
            <tbody>
			  <tr>
                <td width="20%">Name</td>
                <td>
                      <input type="text" name="name" value="" class="medium required" />
					  
                </td>
				<td>
				 <button type="submit" class="btn btn-primary" name="submit_member">Save</button>
                        <input type="hidden" id="startDate" name="startDate" value="" />
						</td>
            </tr>
			
            </tbody>
        </table>
    </form>
</div>
	
<script type="text/javascript">// <![CDATA[
    /* Save event Data */
	 jQuery('.day_num').on('click',function()
        {
          var sdate = jQuery(this).attr('data-date');
		  //alert(sdate);
		   jQuery("#startDate").val('');
		  jQuery("#startDate").val(sdate);
		   jQuery(".form-popup").show();
		  
		  
     });
    jQuery('#form').on('submit', function (e) {
        var form=jQuery(this);
        if (!e.isDefaultPrevented()) {
          //  jQuery('.loader').css("display","inline-block");
            var dataArr = jQuery(this).serializeArray();
            dataArr.push({ name: "action", value:"cpd_ajax"});
            dataArr.push({ name: "task", value:"save_event"});
            dataArr.push({ name: "security", value:window.lmapps_site_nonce});
            jQuery.ajax({
                method: "POST",
                url: adminAjax,
                data: dataArr,
                crossDomain: true,
                dataType: 'json'
            }).done(function (response) {
                jQuery('.loader').hide();
                var res = eval(response);
                if (res.success != "undefined" && res.success == 1) {
					 jQuery(".form-popup").hide();
                    alert(res.message);
					location.reload();
                }
                else {
                    alert(res.message);
                }
            })
        }
        e.preventDefault();
    });// ]]>
</script>
