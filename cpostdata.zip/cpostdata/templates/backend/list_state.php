<?php
/**
 * Created by PhpStorm.
 * User: oculus
 * Date: 1/30/2017
 * Time: 9:46 AM
 */
if(isset($_POST['delete']))
{
	$childArr=array();
    $data['id']     =$_POST['id'];
    $data['table']  =$this->tableState;
    $childArr['table']    = $this->tableCity;
	$childArr['key']      = "state_id";
	$childArr['value']    = $data['id'];
	$response            = $this->deleteChildRecord($childArr);
	if ($response['success'] == 1) {
		$res=$this->deleteRecord($data);
			$message        =$res['message'];
		if($res['success']==1)
		{
			$msg_class  ="success";
		}
		else{
			$msg_class  ="error";
		}
	}else{
		$msg_class  ="error in child";
	}
    
   
}
$results        =$this->getData($this->tableState,"where name like '%".$search_text."%' ORDER BY created_date desc");
$total_record   =$this->getData($this->tableState,"where name like '%".$search_text."%'  ORDER BY created_date desc",true);
$paging         =$libObj->getPages($total_record, $page,'State',$search_text);
?>

<div class="wrap">
    <div class="icon32 icon32-posts-post" id="icon-edit"><br></div>
    <h2><?php echo $pagetitle; ?>
        <a href="<?php echo $detailPage; ?>" class="add-new-h2 add-new-field">Add New State</a>
        <span class="subtitle"><?php if($search_text!=""){ echo "Search results for “".$search_text."”";} ?></span></h2>
    <?php if(isset($message) && $message!=''){ ?>
        <div id="message" class="updated <?php echo $msg_class; ?>"><p><?php echo $message; ?></p></div>
    <?php } ?>
    <form id="posts-filter" action="" method="post">
        <p class="search-box" style="padding:5px 0px;">
            <label class="screen-reader-text" for="post-search-input">Search State:</label>
            <input type="search" id="input-search" name="input-search" value="<?php echo $search_text; ?>">
            <input type="submit" name="search" id="search" class="button" value="Search State">
        </p>
    </form>
    <div class="fullwidth-panel">
        <table cellspacing="0" class="wp-list-table widefat fixed pages">
            <thead>
            <tr>
                <th>State Name</th>
            </tr>
            </thead>
            <tbody>
            <?php if($total_record>0){
                $count=0;
                foreach($results as $k=>$v) {?>
                    <tr <?php echo ($count%2==0?"class='alternate'":''); $count++; ?>>
                        <td>
                            <?php echo $v['name']; ?>
                            <div class="row-actions">
                                <form method="post" action="">
                                    <input type="hidden" name="id" value="<?php echo $v['id']; ?>" />
                                     <a href="<?php echo $detailPage.'&id='.$v['id']; ?>">Edit</a>
                                    <?php /* | <input type="submit" class="deleteWithChildRecord custom-button" name="delete" value="Delete" /> */ ?>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php }} else { ?>
                <tr><td colspan="1" class='empty'>No States found.</td></tr>
            <?php } ?>
            </tbody>
            <tfoot>
            <tr>
                <th>State Name</th>
            </tr>
            </tfoot>
        </table>
    </div>
    <div class="tablenav bottom">
        <div class="alignleft actions"></div>
        <?php if( isset($paging) && $paging!= '' ){ echo $paging;} ?>
        <br class="clear">
    </div>
</div>
