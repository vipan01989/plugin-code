<?php
/**
 * Created by PhpStorm.
 * User: oculus
 * Date: 1/30/2017
 * Time: 9:46 AM
 */
$id         =0;
global $wpdb;
if(isset($_GET['id']))
    $id=$_GET['id'];

if(isset($_POST['submit']))
{
    $data=$_POST;
    $data['id']=$_POST['id'];
    $data['action']=($data['id']==0?"add":"edit");
    if(!$this->checkRecordAlreadyExists($this->tableState,"id!=".$data['id'],"name='".$_POST['name']."'")) {
        $id = $this->createQuery($this->tableState, $data, true);
        if ($data['id'] == 0) {
            $message = "State saved successfully.";
        } else {
            $message = "State updated successfully.";
        }
    }
    else
    {
        $message = "State Already Exists.";
    }
}
$results=array();
if($id!=0)
    $results=$this->getData($this->tableState,"where id=".$id);

?>

<div class="wrap">
    <div class="icon32 icon32-posts-post" id="icon-edit"><br></div>
    <h2><?php echo $pagetitle; ?>
        <a href="<?php echo $detailPage; ?>" class="add-new-h2 add-new-field">Add New State</a>
    </h2>
    <?php if(isset($message) && $message!=''){ ?>
        <div id="message" class="updated"><p><?php echo $message; ?></p></div>
    <?php } ?>
    <form name="form" id="form" method="post" action="">
        <table cellspacing="0" class="wp-list-table widefat fixed posts">
            <tbody>
            <tr>
                <td width="20%">Name</td>
                <td>
                    <input type="text" name="name" value="<?php echo @$results[0]['name']; ?>" class="medium required" />
                </td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" class="button button-primary" name="submit" id="submit" value="<?php echo $id==0?'Save':'Update'; ?>" />
                    <input type="button" name="cancel" class="button button-primary" id="cancel" value="Cancel" />
                    <input type="hidden" name="id" id="id" value="<?php echo $id; ?>" />
                </td>
            </tr>
            </tbody>
        </table>
    </form>
</div>
<script type="text/javascript">
    $jQu(document).ready(function(){
        $jQu('#cancel').on('click',function()
        {
            window.location.href="<?php echo $viewPage; ?>";
        });
        jQuery('#submit').on('click',function()
        {
            jQuery("#form").validate();
        });
    });
</script>
