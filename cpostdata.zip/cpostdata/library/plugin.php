<?php
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly
    $noticeOnPage=0;
class cpd_plugin extends cpd_shortcode
{

    public $logError      = false;
	public $subMenu       = array();

	
	public static function init()
    {
        new self;
       
    }

    public function __construct()
    {
        parent::__construct();
         $this->subMenu		= array( //"state" 		  => "Manage States"
		   
		   "event" 		    => "My Events"
		 
		 );

	
		
        add_action('admin_menu', array($this,'createAdminMenu'));
        add_action('admin_enqueue_scripts', array($this,'addScriptsAndStyles'));
        add_action('wp_enqueue_scripts', array($this,'addScriptsAndStylesOnFront'));

        add_action('wp_ajax_cpd_ajax', array($this,'cpd_admin_ajax'));
        add_action('wp_ajax_nopriv_cpd_ajax', array($this,'cpd_admin_ajax'));

        add_filter("body_class", array($this,"add_body_class"));


        add_action('admin_init', array($this,'cpd_admin_init'));
        add_action('admin_notices', array($this,'cpd_admin_notices'));
        add_action('wp_footer', array($this,'includeFooterScripts'), 20);
        add_action('in_admin_footer', array($this,'includeAdminFooterScripts'), 20);

        register_activation_hook(CPD_FILE, array($this,'cpd_activate'));

        //add_action( 'admin_init', array($this,'cpd_register_settings'));

        add_action('wp_ajax_cpd_api_request', array($this,'cpd_api_request'));
        add_action('wp_ajax_nopriv_cpd_api_request', array($this,'cpd_api_request'));
        
        add_action('add_meta_boxes', array($this,'cpd_meta_box_add'));
        add_action('save_post', array($this,'cpd_meta_box_save'));
        
        add_filter('wp_mail_from', array($this,'configure_from_email'));
        add_filter('wp_mail_from_name', array($this,'configure_from_name'));
        add_action('delete_user', array($this,'save_deleted_user_detail'));
        //add_action('wpcf7_before_send_mail', array($this, 'cpd_save_to_the_database' )); 

        
    }


	// hook into wpcf7_before_send_mail
	function cpd_save_to_the_database($contact_form){
		global $wpdb;
		$submission = WPCF7_Submission::get_instance();
		$data=$submission->get_posted_data();
		//print_r($data);
		if(!empty($data['user_email'])){
		
			$result= $this->checkBusinessSignup($data['user_email']);
			if(count($result)>0){
			   if(!empty($result[0]['salesman_id'])){
					$user_info = get_userdata($result[0]['salesman_id']);
					$toEmail=$user_info->user_email;
					$mailProp = $contact_form->get_properties('mail');
					$cclist= $mailProp['mail']['recipient'];
                    $mailProp['mail']['recipient'] = $toEmail;
					if(!empty($cclist)){
						$mailProp['mail']['additional_headers'] = "Cc: ".$cclist;
					}
                    $contact_form->set_properties(array('mail' => $mailProp['mail']));
				}
				
			}
			
		}


	}

    function errorHandler($errno, $errstr, $errfile, $errline)
    {
        if (!(error_reporting() & $errno)) {
            // This error code is not included in error_reporting
            return;
        }
        $type = $this->FriendlyErrorType($errno);
        $this->errorMessage .= "Error: [" . $type . "] $errstr in $errfile on line number $errline\n";

        /* Don't execute PHP internal error handler */
        return true;
    }

    public function handleErrors()
    {
        $error = error_get_last();

        # Checking if last error is a fatal error
        if (($error['type'] === E_ERROR) || ($error['type'] === E_USER_ERROR)) {
            # Here we handle the error, displaying HTML, logging, ...
            $type = $this->FriendlyErrorType($error['type']);
            $this->errorMessage .= "Error: [" . $type . "] " . $error['message'] . " in " . $error['file'] . " on line number " . $error['line'];
            $result["success"] = false;
            $result["message"] = $this->errorMessage;
            header('content-type: application/json');
            $response = $result;
            echo json_encode($response);
            die();
        } else if ($error['type'] != "") {
            $type = $this->FriendlyErrorType($error['type']);
            $this->errorMessage .= "Error: [" . $type . "] " . $error['message'] . " in " . $error['file'] . " on line number " . $error['line'];
        }
    }

    public function FriendlyErrorType($type)
    {
        switch ($type) {
            case E_ERROR: // 1 //
                return 'E_ERROR';
            case E_WARNING: // 2 //
                return 'E_WARNING';
            case E_PARSE: // 4 //
                return 'E_PARSE';
            case E_NOTICE: // 8 //
                return 'E_NOTICE';
            case E_CORE_ERROR: // 16 //
                return 'E_CORE_ERROR';
            case E_CORE_WARNING: // 32 //
                return 'E_CORE_WARNING';
            case E_COMPILE_ERROR: // 64 //
                return 'E_COMPILE_ERROR';
            case E_COMPILE_WARNING: // 128 //
                return 'E_COMPILE_WARNING';
            case E_USER_ERROR: // 256 //
                return 'E_USER_ERROR';
            case E_USER_WARNING: // 512 //
                return 'E_USER_WARNING';
            case E_USER_NOTICE: // 1024 //
                return 'E_USER_NOTICE';
            case E_STRICT: // 2048 //
                return 'E_STRICT';
            case E_RECOVERABLE_ERROR: // 4096 //
                return 'E_RECOVERABLE_ERROR';
            case E_DEPRECATED: // 8192 //
                return 'E_DEPRECATED';
            case E_USER_DEPRECATED: // 16384 //
                return 'E_USER_DEPRECATED';
        }
        return "";
    }

    public function cpd_activate()
    {

        $notices = get_option('_cpd_admin_notices', array());
        $indexedPosts = get_option('_cpd_indexed_posts');
        if ($indexedPosts != "" && $indexedPosts != 0 && $indexedPosts != false) {
            $syncStatus = parent::getSyncStatus();
            if ($syncStatus) {
                $msg = cpd_plugin::admin_reindex_messages();
                if (!$this->checkNotices($notices, "recommended to")) {
                    $notices[] = $msg;
                }
            }

        } else {
            $msg = cpd_plugin::admin_notice_messages();
            if (!$this->checkNotices($notices, "been activated")) {
                $notices[] = $msg;
            }
        }
        update_option('_cpd_admin_notices', $notices);
        $this->createTables();
    }

    public function checkNotices($notices, $word)
    {
        if (count($notices) > 0) {
            foreach ($notices as $k => $v) {
                if (strpos($v, $word) !== false) {
                    return true;
                }
            }
        }
        return false;
    }

    public function createTables()
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      /*  $sql = "CREATE TABLE IF NOT EXISTS $this->tableState (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `name` varchar(200) DEFAULT NULL,
                  `created_date` datetime DEFAULT NULL,
                  `modified_date` datetime DEFAULT NULL,
                  `status` int(11) DEFAULT '1',
                  PRIMARY KEY (`id`)
		        ) $charset_collate;";
        dbDelta($sql);*/
		
		 $sql = "CREATE TABLE IF NOT EXISTS $this->tableEvent (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `name` varchar(200) DEFAULT NULL,
				  `startDate` datetime DEFAULT NULL,
				  `EndDate` datetime DEFAULT NULL,
				  `created_date` datetime DEFAULT NULL,
                  `modified_date` datetime DEFAULT NULL,
                  `status` int(11) DEFAULT '1',
                  PRIMARY KEY (`id`)
		        ) $charset_collate;";
        dbDelta($sql);
       
       
        
    }

    public static function admin_notice_messages()
    {
        return "";
    }

    public function cpd_admin_init()
    {
        global $cpdAPIClient;
        $current_version = CPD_PLUGIN_VERSION;

    }
    function cpd_admin_notices()
    {
        $notices = get_option('_cpd_admin_notices', array());

        if (count($notices) > 0) {
            foreach ($notices as $notice) {
                echo "<div class='update-nag cpd-notices'>$notice</div>";
            }
            delete_option('_cpd_admin_notices');
        }
    }


    public function add_body_class($classes)
    {
        global $post;
        $classes[] = "cpd_search_page";
        return $classes;
    }

    public function getDomain()
    {
        $domain         = get_option('siteurl');
        $find           = array('http://','https://');
        $replace        = array('','');
        $domain         = str_replace($find, $replace, $domain);
        $this->domain   = strtolower($domain);
        return $this->domain;
    }

    public function createAdminMenu()
    {
        add_menu_page(__('CPostdata', 'cpd'), __('CPostdata', 'cpd'), $this->lqMenuCapabilities, 'cpd', array($this,"dashboard"), CPD_BASE_URL . '/assets/images/logo.png');
        if(count($this->subMenu) > 0){
			foreach($this->subMenu as $slug => $menu){
				add_submenu_page('cpd',__($menu, 'cpd'), __($menu, 'cpd'), $this->lqMenuCapabilities, $slug, array($this, "manageSubmenuItems"));
			}
		}
    }

    public function addScriptsAndStyles($hook)
    {
		wp_register_style('cpd_bootstrap_css', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css', true, time());
        wp_register_style('cpd_admin_css', CPD_BASE_URL . '/assets/css/backend/stylesheet.css', false, time());
		wp_enqueue_style('cpd_bootstrap_css');	
	    wp_enqueue_style('cpd_admin_css');
        //if (strpos($hook, 'cpd') !== FALSE) {
            wp_register_script('cpd_admin_validate_js', CPD_BASE_URL . '/assets/js/backend/jquery.validate.min.js', array('jquery'), time());
            wp_register_script('cpd_bootstrap_js', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js', array('jquery'), time());
			 wp_register_script('cpd_admin_js', CPD_BASE_URL . '/assets/js/backend/script.js', array('jquery'), time());
			 wp_register_script('cpd_admin_js', CPD_BASE_URL . '/assets/js/backend/calendar.js', array('jquery'), time());
			
			wp_enqueue_script('cpd_bootstrap_js');
			wp_enqueue_script('cpd_admin_validate_js');
			wp_enqueue_script('cpd_admin_js');
			
          
        //}
    }

    public function includeFooterScripts()
    {
        ?>
        <script type="text/javascript">// <![CDATA[
            var adminAjax           = '<?php echo admin_url('admin-ajax.php');?>';
            var cpds_site_nonce   = "<?php echo wp_create_nonce($this->siteNonceString);?>";
             // ]]>
        </script>
    <?php }
     public function includeAdminFooterScripts()
    {
        ?>
        <script type="text/javascript">// <![CDATA[
            var adminAjax           = '<?php echo admin_url('admin-ajax.php');?>';
            var cpds_site_nonce   = "<?php echo wp_create_nonce($this->adminNonceString);?>";
            // ]]>
        </script>
    <?php }

    public function addScriptsAndStylesOnFront()
    {
        if (!is_admin()) {
            wp_register_style('cpd_bootstrap_css', CPD_BASE_URL . '/assets/css/frontend/bootstrap.min.css', true, time());
            wp_register_style('cpd_front_css', CPD_BASE_URL . '/assets/css/frontend/stylesheet.css', false, time());
            wp_enqueue_style('cpd_bootstrap_css');
            wp_enqueue_style('cpd_front_css');

            wp_register_script('cpd_bootstrap_js', CPD_BASE_URL . '/assets/js/frontend/bootstrap.min.js', array('jquery'), time());
            wp_register_script('cpd_front_jquery_ui_js', CPD_BASE_URL . '/assets/jquery-ui/js/jquery-ui.min.js', array('jquery'), time());
            wp_register_script('cpd_front_js', CPD_BASE_URL . '/assets/js/frontend/script.js', array('jquery'), time());
            wp_register_script('cpd_front_validator_js', CPD_BASE_URL . '/assets/js/frontend/validator.js', array('jquery'), time());
            wp_register_script('cpd_front_cookie_js', CPD_BASE_URL . '/assets/js/frontend/js.cookie.js', array('jquery'), time());
            
          
            wp_enqueue_script('cpd_bootstrap_js');
            wp_enqueue_script('cpd_front_jquery_ui_js');
            wp_enqueue_script('cpd_front_validator_js');
            wp_enqueue_script('cpd_front_js');
            wp_enqueue_script('cpd_front_cookie_js');
			
            if (!wp_script_is('jquery', 'enqueued')) {
                wp_enqueue_script('jquery');
            }
        }
    }

    public function dashboard()
    {
		include_once(CPD_BASE_PATH . '/templates/backend/dashboard.php');
    }

    public function returnOnDie($message)
    {
        if ($this->resultSent == 0) {
            $result["success"]  = false;
            $result["message"]  = $message;
            $result["errors"]   = $this->errorMessage;
            header('content-type: application/json');
            $response           = $result;
            echo json_encode($response);
            exit;
        }
    }

    public function dieHandler($param)
    {
        die();
    }

    public function checkIfInAdmin()
    {
        if ((strpos(strtolower($_SERVER[HTTP_REFERER]), strtolower(site_url())) !== FALSE && strpos(strtolower($_SERVER[HTTP_REFERER]), "wp-admin") !== FALSE)) {
            return true;
        }
        return false;
    }

    private function checkSecurity($nonce)
    {
        if (!$this->checkIfInAdmin()) {
            register_shutdown_function(array($this,'returnOnDie'), 'Invalid nonce on frontend.');
            if (check_ajax_referer($this->siteNonceString, 'security')) {
                return true;
            }
        } else if (current_user_can("activate_plugins")) {
            register_shutdown_function(array($this,'returnOnDie'), 'Invalid nonce on admin.');
            if (check_ajax_referer($this->adminNonceString, 'security')) {
                return true;
            }
        }
        return false;
    }

    public function cpd_admin_ajax()
    {
        error_reporting(0);
        register_shutdown_function(array($this,'handleErrors'));
        set_error_handler(array($this,"errorHandler"));
       
        if (!empty($_POST)) {
			
            $task = $_POST['task'];
            $nonce = $_POST['security'];
            add_filter('wp_die_ajax_handler', array($this,'dieHandler'));
           // if ($this->checkSecurity($nonce)) {
                $post = $this->sanitizeVariables($_POST);
                switch ($task) {
               
                     case "save_event":
                        $result = $this->saveEvent($post);
                        break;
					default:
					
						$result = array('success'=>0, 'message'=>'Parameter missing, please try again.');
				}
			/*}else{
				$result = array('success'=>0, 'message'=>'Insecure request, please try again.');
			}*/
		}else{
			$result = array('success'=>0, 'message'=>'Invalid request, please try again.');
		}

		header('content-type: application/json');
		$result['errors'] = $this->errorMessage;
		$response = $result;
		$this->resultSent = 1;
		echo json_encode($response);
		exit;
	}
   public function saveEvent($data)
    {

        $response['success'] = 0;
        if (!isset($data['id'])) {
            $data['id'] = 0;
        }
        $data['action'] = $data['id'] == 0 ? "add" : "edit";

            $id = $this->createQuery($this->tableEvent, $data, true);
            $response['success'] = 1;
            if ($data['id'] == 0) {
                $response['message'] = "Event successfully.";
            } else {
                $response['message'] = "Event updated successfully.";
            }
        return $response;
    }
    public function checkUniqueIdentificationCode($uin)
    {
        $response = parent::checkUniqueIdentificationCode($uin);
        return $response;
    }

    

    public function manageSubmenuItems(){
		$page       			= $_GET['page'];
		$action     			= $_GET['action'];
		$viewPage   			= $this->siteUrl.'/wp-admin/admin.php?page='.$page;
		$detailPage 			= $this->siteUrl.'/wp-admin/admin.php?page='.$page.'&action=detail';
		$pagetitle				=$this->subMenu[$page];
		switch($action){
			
			case "detail":
				include_once(CPD_BASE_PATH . "/templates/backend/detail_".$page.".php");
			break;
			case "view":
			     include_once(CPD_BASE_PATH.'/library/libClass.php');
			     $libObj                 = new cpdLibrary();
				 $libObj->itemsPerPage   = $this->itemsPerPage;

				$libObj->currentPage    = ($_GET['num']!='') ? $_GET['num'] : 1 ;
				$this->offset           = $libObj->itemsPerPage *($libObj->currentPage-1);
				$search_text            ="";
				$total_record           =0;
				$msg_class              ="";
				$search_status          ="";
				include_once(CPD_BASE_PATH . "/templates/backend/view_".$page.".php");
			break;
			default:
				include_once(CPD_BASE_PATH.'/library/libClass.php');
				$libObj                 = new cpdLibrary();
				$libObj->itemsPerPage   = $this->itemsPerPage;

				$libObj->currentPage    = ($_GET['num']!='') ? $_GET['num'] : 1 ;
				$this->offset           = $libObj->itemsPerPage *($libObj->currentPage-1);
				$search_text            ="";
				$total_record           =0;
				$msg_class              ="";
				$search_status          ="";

				if(isset($_POST['search']))
				{
					$search_text=trim($_POST['input-search']);
					if(isset($_POST['active_status']) && $_POST['active_status']<2){
					 $search_status=trim($_POST['active_status']);
					 if($search_status==''){
						 unset($_REQUEST['active_status']);
					 }
					}
					$libObj->currentPage    = 1 ;
					$this->offset           = $libObj->itemsPerPage *($libObj->currentPage-1);
				}
				else if(isset($_REQUEST['s']))
				{
					$search_text=trim($_REQUEST['s']);
					$_REQUEST['search_text']=$_REQUEST['s'];
				}
				if(isset($_REQUEST['active_status'])){
					$search_status=$_REQUEST['active_status'];
					$_REQUEST['active_status']=$_REQUEST['active_status'];
				}
				include_once(CPD_BASE_PATH . "/templates/backend/list_".$page.".php");
		}
    }
      
    public function cpd_api_request()
    {
	
		error_reporting(0);
        register_shutdown_function(array($this, 'handleErrors'));
        set_error_handler(array($this, "errorHandler"));
        if (!empty($_POST)) {
            $task 		= $_POST['task'];
            $perform 	= $_POST['perform'];
            add_filter('wp_die_ajax_handler', array($this, 'dieHandler'));
            $data = $this->sanitizeVariables($_POST);
            switch ($task) {
                case "apiRequest":
                    $result = $this->performApiRequest($perform, $data);
				break;
            }
        }
        header('Access-Control-Allow-Origin: *');
        header('content-type: application/json');
        $result['errors'] = $this->errorMessage;
        $response = $result;
        $this->resultSent = 1;
        echo json_encode($response);
        exit;
    }
    
    private function performApiRequest($perform = "", $data = array()){
		$result = array("success"=>0, "message"=> "There is some issue with the request. Please try again.");
		switch($perform){
			
			case "api_user_settings";
			      $result=$this->checkAPI($data);
			break;
			
			
		}
		return $result;
	}
	
	
    public function checkAPI($post = array()){
        $result["success"]  = 1;
        $result["message"]  = "just testing the API";
        $result["post"]     = $post;
        return $result;
    }



    
}
