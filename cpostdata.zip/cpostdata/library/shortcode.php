<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
class cpd_shortcode extends cpd_hooks{
	
	function __construct(){
		parent::__construct();
		//add_action( 'widgets_init', array($this, 'registerWidgets') );
		//if(!is_admin()) {
			add_action( 'init', array($this, 'addShortcodes') );
		//}
	}
	public function addShortcodes(){
		   add_shortcode('test-scode',array($this ,'test_scode'));
			
	}
  public function test_scode()
    {
        ob_start();
        include_once(LMAPP_BASE_PATH.'/templates/frontend/dashboard.php');
        $content=ob_get_clean();
        return $content;
    }
	
	/*public function registerWidgets(){
		require_once(SIQ_BASE_PATH.'/library/widget-search.php');
		register_widget( 'SIQ_Search_Widget' );
	}*/
}