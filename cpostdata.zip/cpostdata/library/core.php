<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
class cpd_core{
	
    public $pluginOptions;
    public $pluginSettings;
    public $logErrors;
    public $homeUrl;
	public $siteUrl;
	public $uploadDirPath;
	public $uploadDirUrl;
    public $useErrorLog = false;
    public $upload_info;
    public $adminNonceString = "cpd_admin_nonce";
    public $siteNonceString = "cpd_site_nonce";
    public $tablePrefix = "cpd_";
	public $itemsPerPage;
	public $offset;
	public $ApiItemsPerPage;
	public $lqMenuCapabilities;
	public $tableState;
	public $tableEvent;
	public $specialFields=array();
	
	 function __construct()
    {
		 $this->setTableNames();
		
		$this->pluginOptions                = array('data_type' => '_cpd_data_type');
        $this->validImageTypes              = array("image/png", "image/jpg", "image/jpeg");
		$this->itemsPerPage                 = 15;
		$this->ApiItemsPerPage              = 5;
		$this->offset                       = 0;
        $this->maxImageSize                 = "1024000";    //1 MB
		$this->siteUrl                      = get_site_url();
        $this->homeUrl                      = network_home_url();
        $this->upload_info                  = wp_upload_dir();
        $this->uploadDirPath                = $this->upload_info['basedir'];
        $this->uploadDirUrl                 = $this->upload_info['baseurl'];
		$this->lqMenuCapabilities           = "activate_plugins";
		
		
		add_action('current_screen', array($this, 'check_current_screen'), 99);
	}
	
	public function setTableNames()
    {
        global $wpdb;
        $this->tableUsers                                   = $wpdb->prefix . "users";
        $this->currentUserMeta                              = $wpdb->prefix . "usermeta";
        $this->tableEvent                                   = $wpdb->prefix . $this->tablePrefix . "Events";
		
	}
	
	 public function check_current_screen(){
        $screen = get_current_screen();
    }
	protected function sanitizeVariables($input)
    {
        $output = array();
        if (is_array($input) && count($input) > 0) {
            foreach ($input as $k => $v) {
                if (!in_array($k, $this->keysExepmtedFromSanitize)) {
                    $output[$k] = sanitize_text_field($v);
                } else {
                    $output[$k] = $v;
                }
            }
        }
        return $output;
    }

    public function log_error($error, $onlySelected = false)
    {
        if ($this->useErrorLog == true || $onlySelected == true) {
            $this->log(true);
            error_log(print_r($error, true));
        }
    }

    public function log($logError = false)
    {
        $this->errorFileDir = LMAPP_BASE_PATH . '/logs';
        $this->errorFile = $this->errorFileDir . '/error.log';
        if (!file_exists($this->errorFileDir)) {
            @mkdir($this->errorFileDir, 0777, true);
        } else if (substr(fileperms($this->errorFileDir), 0, -3) != '777') {
            @chmod($this->errorFileDir, 0777);
        }

        $this->logErrors = $logError;
        if ($this->logErrors) {
            ini_set('error_log', $this->errorFile);
            if (!file_exists($this->errorFile)) {
                $fh = @fopen($this->errorFile, 'w');
                @fclose($fh);
                @chmod($this->errorFile, 0777);
            }
        }
    }

    function getPluginSettings($param = '')
    {
        $setting = array();

        foreach ($this->pluginOptions as $k => $v) {
            $setting[$k] = get_option($v, NULL);
        }
        $this->pluginSettings = $setting;
        return $setting;
    }
	
	  /* Get Data from database */
    /* This function is used to get all data from database */
    public function getAllData($table, $order_by = "", $condition = "", $count = false)
    {
        global $wpdb;
        $where = "";
        if ($condition != "") {
            $where = $condition;
        }
        if ($count == true) {
            $query = " SELECT count(*) as count FROM " . $table . " " . $where . "";
            $myrows = $wpdb->get_var($query);
        } else {
            $query = " SELECT * FROM " . $table . " " . $where . " " . $order_by . "";
            $myrows = $wpdb->get_results($query, ARRAY_A);
        }
        return $myrows;
    }

    /* This function is used to get all data from database according to limit */
    public function getData($table, $condition = "", $count = false)
    {

        global $wpdb;
        $where = "";
        if ($condition != "") {
            $where = $condition;
        }
        if ($count == true) {
            $query = " SELECT count(*) as count FROM " . $table . " " . $where . "";
            $myrows = $wpdb->get_var($query);
        } else {
            $query = " SELECT * FROM " . $table . " " . $where . "";
            $query .= " LIMIT " . $this->offset . "," . $this->itemsPerPage;
            $myrows = $wpdb->get_results($query, ARRAY_A);
        }
        return $myrows;
    }

    /* This function is used to get Record ID from database */
    public function getRecordId($table, $key, $value)
    {

        global $wpdb;
        $query = " SELECT id as count FROM " . $table . " WHERE " . $key . "='" . $value . "'";
        $id = $wpdb->get_var($query);
        $id = ($id == "" ? NULL : $id);
        return $id;
    }

    /* This function is used to delete record */
    public function deleteRecord($data)
    {
        global $wpdb;
        $tableName = $data['table'];
        $id = $data['id'];

        global $wpdb;
        $delete = $wpdb->query($wpdb->prepare("DELETE FROM " . $tableName . "  WHERE id = %d ", $id));
        if (is_wp_error($delete)) {
            $return['success'] = 0;
            $return['message'] = $wpdb->last_error;

        }else{
			if($data['file_name']!='' && $data['path']!=''){
				
				  $this->deleteImageByAjax($data['path'], $data['file_name']);
				}
            $return['success'] = 1;
            $return['message'] = "Record deleted successfully.";
        }
        return $return;
    }

    /* This function is used to delete record according to key and value */
    public function deleteChildRecord($data)
    {
        global $wpdb;
        $tableName = $data['table'];
        $key = $data['key'];
        $value = $data['value'];

        global $wpdb;
        $delete = $wpdb->query($wpdb->prepare("DELETE FROM " . $tableName . "  WHERE " . $key . " = %d ", $value));
        if (is_wp_error($delete)) {
            $return['success'] = 0;
            $return['message'] = $wpdb->last_error;
        } else {
            $return['success'] = 1;
            $return['message'] = "Record deleted successfully.";
        }
        return $return;
    }

    public function getDbFields($tableName, $labels = false)
    {
        global $wpdb;
        $query = 'SHOW COLUMNS FROM ' . $tableName . '';
        $data = $wpdb->get_results($query);

        if (!$labels) {
            foreach ($data as $k => $v) {
                if (array_key_exists($tableName, $this->specialFields)) {
                    if (array_key_exists($v->Field, $this->specialFields[$tableName])) {
                        $fields[$k] = $this->specialFields[$tableName][$v->Field];
                    } else {
                        $fields[$k] = array(
                            'name' => $v->Field
                        );
                        $fields[$k] = array_merge($fields[$k], $this->getFieldsType($v->Type));
                    }
                } else {
                    $fields[$k] = array(
                        'name' => $v->Field
                    );
                    $fields[$k] = array_merge($fields[$k], $this->getFieldsType($v->Type));
                }
            }
        } else {
            foreach ($data as $k => $v) {
                $fields[$v->Field] = $v->Field;
            }
        }
        return $fields;
    }

    public function getFieldsType($type)
    {
        preg_match('/(.*)\((.*)\)/', $type, $matches);
        if (count($matches) <= 0) {
            $matches[1] = $type;
            $matches[2] = '';
        }
        $typeArray = array(
            'type' => $matches[1],
            'limit' => $matches[2]
        );
        return $typeArray;
    }

    public function createQuery($tableName, $data, $isDate = false)
    {
        global $wpdb;
        $lastId = '';
        $action = $data['action'];
        $currentDate = date("Y-m-d H:i:s");
        $processedData = $this->generateQuery($data, $tableName);
        $where = array(
            'id' => $data['id']
        );
        switch ($action) {
            case 'add':
                if ($isDate) {
                    $processedData['created_date'] = $currentDate;
                    $processedData['modified_date'] = $currentDate;
                }
                $wpdb->insert($tableName, $processedData);
                $lastId = $wpdb->insert_id;
                break;

            case 'edit':
                if ($isDate) {
                    $processedData['modified_date'] = $currentDate;
                }
                $wpdb->update($tableName, $processedData, $where);
                $lastId = $data['id'];
                break;
            default:
        }
        return $lastId;
    }

    public function generateQuery($data, $tableName)
    {
        $fieldsArray = array();

        $fields = $this->getDbFields($tableName);

        foreach ($fields as $k => $v) {
            if (array_key_exists($v['name'], $data)) {
                if ($v['type'] == 'date' || $v['type'] == 'datetime') {
                    $data[$v['name']] = date('Y-m-d', strtotime($data[$v['name']]));
                }
                $fieldsArray = array_merge($fieldsArray, array(
                    $v['name'] => stripcslashes($data[$v['name']])
                ));
            }
        }
        return $fieldsArray;
    }

    /* This function is used to check record exists or not */
    public function checkRecordExists($table, $key, $value)
    {
        global $wpdb;
        $return = false;
        $query = "SELECT COUNT(*) FROM $table WHERE $key='" . $value . "'";
        $count = $wpdb->get_var($query);
        if ($count > 0) {
            $return = true;
        }
        return $return;
    }
    /* This function is used to check record already exists or not */
    public function checkRecordAlreadyExists($table,$primaryKeyCondition,$checkKeyCondition="")
    {
        global $wpdb;
        $return = false;
        $query = "SELECT COUNT(*) FROM $table WHERE $primaryKeyCondition";
        if($checkKeyCondition!="")
        {
            $query .=" AND ".$checkKeyCondition;
        }
        $count = $wpdb->get_var($query);
        if ($count > 0) {
            $return = true;
        }
        return $return;
    }
	
	
}