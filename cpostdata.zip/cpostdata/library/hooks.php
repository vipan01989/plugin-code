<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
class cpd_hooks extends cpd_core{
	
	public function __construct(){
		parent::__construct();
		$this->executeHooks();
	}
	
	public function executeHooks(){
		//add_action( 'transition_post_status', 	array($this, 'youFunction'), 9998, 3);
		
	}
	

	
	public function youFunction($new_status, $old_status=null, $post=null){

	}

}
