$jQu                        = jQuery;
var selected_city           ="";
var selected_communities    ="";
var selected_categories     ="";
var selected_schools        ="";
var no_community_message    ="There is no Community.";
//var max_image_size          ="1024000";
var modals					= [];
/*Date picker script for date class*/
$jQu( function() {
    $jQu( ".date" ).datepicker({
        dateFormat: "mm/dd/yy",
        maxDate: '0',
        yearRange: '-100:-0',
        defaultDate:"-0y-m-d",
		changeMonth: true,
		changeYear: true
    });
} );

$jQu( function() {
    $jQu( ".dob" ).datepicker({
        dateFormat: "mm/dd/yy",
        maxDate: '0',
		changeMonth: true,
		changeYear: true,
		yearRange: '-100:-13',
		defaultDate:"-13y-m-d"
    });
} );

$jQu( function() {
    $jQu( ".renewalDate" ).datepicker({
		dateFormat: "mm/dd/yy",
        
        
    });
} );
/* alert Message script */
function warningMessage(message)
{
    $jQu('#alertMsg').removeClass('alert-warning').removeClass('alert-success');
    $jQu('#alertMsg').addClass("alert-warning").html(message);
    $jQu('html, body').animate({
        scrollTop: $jQu("form").offset().top -100
    }, 2000);
}
function successMessage(message)
{
    $jQu('#alertMsg').removeClass('alert-warning').removeClass('alert-success');
    $jQu('#alertMsg').addClass("alert-success").html(message);
    $jQu('html, body').animate({
        scrollTop: $jQu("form").offset().top -100
    }, 2000);
}
function warningSpecificMessage(id,message)
{
    $jQu("#"+id).removeClass('alert-warning').removeClass('alert-success');
    $jQu('#'+id).addClass("alert-warning").html(message);
}
function successSpecificMessage(id,message)
{
    $jQu("#"+id).removeClass('alert-warning').removeClass('alert-success');
    $jQu("#"+id).addClass("alert-success").html(message);

}
function modalWarningMessage(modal,message)
{

    modal.find('.alert').removeClass('alert-warning').removeClass('alert-success');
    modal.find('.alert').addClass("alert-warning").html(message);
    
}
function modalSuccessMessage(modal,message)
{
    modal.find('.alert').removeClass('alert-warning').removeClass('alert-success');
    modal.find('.alert').addClass("alert-success").html(message);
    modal.find('form')[0].reset();
   // var timer = modal.data('timer') ? modal.data('timer') : 7000;
    var timer = 800;
    modal.delay(timer).fadeOut(200, function () {
		modal.find('.alert').removeClass('alert-warning').removeClass('alert-success').html("");
        modal.modal('hide');
        if($jQu('.modal:visible').length>0){
			setTimeout(function(){ $jQu("body").addClass("modal-open");}, 500);
	    }
    });
}
/* Check username/email exists in user table */
$jQu(document).on('blur', '#email, #femail', function(e) {
    var email=$jQu(this).val();
    var inp_id=$jQu(this).attr('id');
    var disabled =$jQu(this).prop('disabled');
    if(email!="" && !disabled) {
        $jQu.ajax({
            method: "POST",
            url: adminAjax,
            data: {action: "lmapp_ajax", task: "check_email", security: window.lmapps_site_nonce, email: email},
            crossDomain: true,
            dataType: 'json'
        }).done(function (response) {
            var res = eval(response);
            if (res.success != "undefined" && res.success == 1) {
				if(inp_id!='' && inp_id=='femail'){
				 successSpecificMessage("falertEmailMsg",res.message);
				}else{
				 successSpecificMessage("alertEmailMsg",res.message);	
				}
                
            }
            else {
               if(inp_id!='' && inp_id=='femail'){
				 successSpecificMessage("falertEmailMsg",res.message);
				}else{
				 successSpecificMessage("alertEmailMsg",res.message);	
				}
            }
        }).fail(function (response) {
            var res = eval(response.responseJSON);
            if (res.success != "undefined" && res.success == 0) {
                warningMessage(res.message);
            }
        });
    }
});
/* Check username/email exists in user table */
$jQu(document).on('blur', '#username', function(e) {
    var username=$jQu(this).val();
    var disabled =$jQu(this).prop('disabled');
    if(username!="" && !disabled) {
        $jQu.ajax({
            method: "POST",
            url: adminAjax,
            data: {
                action: "lmapp_ajax",
                task: "check_username",
                security: window.lmapps_site_nonce,
                username: username
            },
            crossDomain: true,
            dataType: 'json'
        }).done(function (response) {
            var res = eval(response);
            if (res.success != "undefined" && res.success == 1) {
                successSpecificMessage("alertUserNameMsg",res.message);
            }
            else {
                warningSpecificMessage("alertUserNameMsg",res.message);
            }
        }).fail(function (response) {
            var res = eval(response.responseJSON);
            if (res.success != "undefined" && res.success == 0) {
                warningMessage(res.message);
            }
        });
    }
});
/* State Modal Script */
$jQu(document).on('click', '.state-modal', function(e) {
    e.preventDefault();
    modals["state-modal"] = $jQu('#myModal');
    modals["state-modal"].modal('show').find('.custom-modal-body').load($jQu(this).attr('href'));
    $jQu('#myModal').find('.modal-title').html('Add State');
    selected_city=$jQu('#city_id').val();
});

/* Save State From Modal */
$jQu(document).on('submit', '.modal #formState', function(event) {
    event.preventDefault();
    var modal=$jQu('#myModal');
    var name=modal.find('#name').val();
    $jQu.ajax({
        method: "POST",
        url: adminAjax,
        data: {action: "lmapp_ajax",task: "save_state",security: window.lmapps_site_nonce, name: name,selected_city:selected_city,modal:true},
        crossDomain: true,
        dataType: 'json'
    }).done(function (response) {
        var res = eval(response);
        if (res.success != "undefined" && res.success == 1) {
            if(res.stateList !="undefined") {
                $jQu('.state_list').html(res.stateList);
                $jQu("form").validator('update');
                $jQu('#city_id').find('option:not(:first)').remove();
                $jQu('#city_id').trigger('change');
            }
            modalSuccessMessage(modal,res.message);
        }
        else
        {
            modalWarningMessage(modal,res.message);
        }
    }).fail(function (response) {
        var res = eval(response.responseJSON);
        if (res.success != "undefined" && res.success == 0) {
            modalWarningMessage(modal,res.message);
        }
    });
});
/* Get City according to state */
$jQu(document).on('change', '#state_id', function(event) {
    var state_id=$jQu(this).val();
    if(state_id!="") {
        $jQu.ajax({
            method: "POST",
            url: adminAjax,
            data: {
                action: "lmapp_ajax",
                task: "get_cities_by_state",
                security: window.lmapps_site_nonce,
                state_id: state_id
            },
            crossDomain: true,
            dataType: 'json'
        }).done(function (response) {
            var res = eval(response);
            if (res.success != "undefined" && res.success == 1) {
                $jQu('.city_list').html(res.cityList);
                $jQu("form").validator('update');
                $jQu('#city_id').trigger('change');
            }
            else {
                warningMessage(res.message);
            }
        }).fail(function (response) {
            var res = eval(response.responseJSON);
            if (res.success != "undefined" && res.success == 0) {
                warningMessage(res.message);
            }
        });
    }
    else
    {
        $jQu('#city_id').find('option:not(:first)').remove();
        $jQu('#city_id').trigger('change');
    }
});
/* City Modal Script */
$jQu(document).on('click', '.city-modal', function(e) {
    e.preventDefault();
    if($jQu('#state_id').val()=="" || $jQu('#state_id').val()==undefined)
    {
        alert("Firstly please select state.");
    }
    else {
        var state_id=$jQu('#state_id').val();
        var state_name=$jQu('#state_id').find("option:selected").text();
         modals["city-modal"] = $jQu('#myModal');
        $jQu('#myModal').modal('show').find('.custom-modal-body').load($jQu(this).attr('href'),
            function(response, status, xhr) {
                $jQu('#myModal').find('#state_name').html(state_name);
                $jQu('#myModal').find('#state_id').val(state_id);
            });
        $jQu('#myModal').find('.modal-title').html('Add City');
    }
});
/* Save City From Modal */
$jQu(document).on('submit', '.modal #formCity', function(event) {
    event.preventDefault();
    var modal=$jQu('#myModal');
    var state_id=modal.find('#state_id').val();
    var name=modal.find('#name').val();
    var community_type=$jQu('.community_list').attr('data');
    $jQu.ajax({
        method: "POST",
        url: adminAjax,
        data: {action: "lmapp_ajax",task: "save_city",security: window.lmapps_site_nonce, state_id:state_id, name:name,modal:true},
        crossDomain: true,
        dataType: 'json'
    }).done(function (response) {
        var res = eval(response);
        if (res.success != "undefined" && res.success == 1) {
            if(res.cityList !="undefined") {
                $jQu('.city_list').html(res.cityList);
                $jQu("form").validator('update');
                $jQu('#city_id').trigger('change');
            }
            modalSuccessMessage(modal,res.message);
        }
        else
        {
            modalWarningMessage(modal,res.message);
        }
    }).fail(function (response) {
        var res = eval(response.responseJSON);
        if (res.success != "undefined" && res.success == 0) {
            modalWarningMessage(modal,res.message);
        }
    });
});
/* Get Communities by city */
$jQu(document).on('change', '#city_id', function(event) {
    event.preventDefault();
    $jQu("form").validator('update');
});
/* Community Modal Script */
$jQu(document).on('click', '.community-modal', function(e) {
    e.preventDefault();
    if($jQu('#city_id').val()==undefined || $jQu('#city_id').val()=="")
    {
        alert("Firstly please select City.");
    }
    else {
        var city_id=$jQu('#city_id').val();
        var city_name=$jQu('#city_id').find("option:selected").text();
        var community_type=$jQu('.community_list').attr('data');
        var communities = [];
         modals["community-modal"] = $jQu('#myModal');
        selected_community="";
        $jQu("input[name^='community_id']:checked").each(function(){
            communities.push($jQu(this).val());
        });
        selected_communities=communities.join(',');
        $jQu('#myModal').modal('show').find('.custom-modal-body').load($jQu(this).attr('href'),
            function(response, status, xhr) {
                $jQu('#myModal').find('#city_name').html(city_name);
                $jQu('#myModal').find('#city_id').val(city_id);
                $jQu('#myModal').find('#type').val(community_type);
            });
        $jQu('#myModal').find('.modal-title').html('Add Community');
    }
});
/* Color picker code */
 $jQu(function(){
  var colpick =  $jQu('.colorpicker').each( function() {
    $jQu(this).minicolors({
      control: $jQu(this).attr('data-control') || 'hue',
      inline: $jQu(this).attr('data-inline') === 'true',
      letterCase: 'lowercase',
      opacity: false,
      change: function(hex, opacity) {
        if(!hex) return;
        if(opacity) hex += ', ' + opacity;
        try {
          console.log(hex);
        } catch(e) {}
         $jQu(this).select();
      },
      theme: 'bootstrap'
    });
  });
  
  var $inlinehex =  $jQu('#inlinecolorhex h3 small');
   $jQu('#inlinecolors').minicolors({
    inline: true,
    theme: 'bootstrap',
    change: function(hex) {
      if(!hex) return;
       $jQuinlinehex.html(hex);
    }
  });
});
/* Sport Modal Script */
$jQu(document).on('click', '.sport-modal', function(e) {
    e.preventDefault();
    modals["sport-modal"] = $jQu('#myModal');
    $jQu('#myModal').modal('show').find('.custom-modal-body').load($jQu(this).attr('href'));
    $jQu('#myModal').find('.modal-title').html('Add Sport');

});
/* Save Sport From Modal */
$jQu('#formSport').validator().on('submit', function (event) {
    event.preventDefault();
    var modal=$jQu('#myModal');
    var name=modal.find('#name').val();
    $jQu.ajax({
        method: "POST",
        url: adminAjax,
        data: {action: "lmapp_ajax",task: "save_sport",security: window.lmapps_site_nonce, name: name,selected_city:selected_city,modal:true},
        crossDomain: true,
        dataType: 'json'
    }).done(function (response) {
        var res = eval(response);
        if (res.success != "undefined" && res.success == 1) {
            if(res.stateList !="undefined") {
                $jQu('.sport_list').html(res.stateList);
                $jQu("form").validator('update');
                $jQu('#sports_id').trigger('change');
                
                    
            }
            modalSuccessMessage(modal,res.message);
        }
        else
        {
            modalWarningMessage(modal,res.message);
        }
    }).fail(function (response) {
        var res = eval(response.responseJSON);
        if (res.success != "undefined" && res.success == 0) {
            modalWarningMessage(modal,res.message);
        }
    });
});
/* Close model script */
$jQu(document).on('click', '.modal-footer button[type="button"]', function (event) {

	if($jQu(this).parents("#formState").length > 0){
		modals["state-modal"].modal("hide");
		if($jQu('.modal:visible').length>1){
			setTimeout(function(){ $jQu("body").addClass("modal-open");}, 500);
	    }
	}
	if($jQu(this).parents("#formCity").length > 0){
		modals["city-modal"].modal("hide");
		if($jQu('.modal:visible').length>1){
			setTimeout(function(){ $jQu("body").addClass("modal-open");}, 500);
	    }
	}
	if($jQu(this).parents("#formSport").length > 0){
		modals["sport-modal"].modal("hide");
		if($jQu('.modal:visible').length>1){
			setTimeout(function(){ $jQu("body").addClass("modal-open");}, 500);
	    }
	}
	if($jQu(this).parents("#formCommunity").length > 0){
		modals["community-modal"].modal("hide");
		if($jQu('.modal:visible').length>1){
			setTimeout(function(){ $jQu("body").addClass("modal-open");}, 500);
	    }
	}
	event.preventDefault();
	return false;
});
/* Close model script */
$jQu(document).on('click', 'div.school#myModal', function (event) {
	    if($jQu('.modal:visible').length>1){
			setTimeout(function(){ $jQu("body").addClass("modal-open");}, 500);
	    }
		//event.preventDefault();
	  //  return false;
});
 $jQu(document).on('change', '#imgInp', function(e) {   
        readURL(this);
    });

/* Change Password */
$jQu('#formChangePassword').validator().on('submit', function (e) {
    var form=$jQu(this);
    e.preventDefault();
    if (!e.isDefaultPrevented()) {
        $jQu('.loader').css("display","inline-block");
        var dataArr = $jQu(this).serializeArray();
        dataArr.push({ name: "action", value:"lmapp_ajax"});
        dataArr.push({ name: "task", value:"change_password"});
        dataArr.push({ name: "security", value:window.lmapps_site_nonce});
        $jQu.ajax({
            method: "POST",
            url: adminAjax,
            data: dataArr,
            crossDomain: true,
            dataType: 'json'
        }).done(function (response) {
            $jQu('.loader').hide();
            var res = eval(response);
            if (res.success != "undefined" && res.success == 1) {
                successMessage(res.message);
                form[0].reset();
            }
            else {
                warningMessage(res.message);
            }
        }).fail(function (response) {
            var res = eval(response.responseJSON);
            if (res.success != "undefined" && res.success == 0) {
                warningMessage(res.message);
                $jQu('.loader').hide();
            }
        });
    }
});
/* Category Modal Script */
$jQu(document).on('click', '.category-modal', function(e) {
    e.preventDefault();
    var categories = [];
    modals["category-modal"] = $jQu('#myModal');
    $jQu("input[name^='category_id']:checked").each(function(){
        categories.push($jQu(this).val());
    });
    selected_categories=categories.join(',');
    $jQu('#myModal').modal('show').find('.custom-modal-body').load($jQu(this).attr('href'),
        function(response, status, xhr) {

        });
    $jQu('#myModal').find('.modal-title').html('Add Category');

});
$jQu(document).on('change', '.file-logo', function(event) {
        var thisElement     =$jQu(this);
        var thisImagePanel  =$jQu(this).parents('.image_panel');
	    var form            = $jQu(this).closest("form");
	    var image           = event.target.files;
	    var operation       = $jQu('#case').val();
		var data            = new FormData();
		if(typeof image != "undefined" && image[0] != null) {
		    data.append("image", image[0]);
		}
		data.append("action","lmapp_ajax");
		data.append("task","save_image");
		data.append("security",window.lmapps_site_nonce);
        data.append("case", operation);
        thisImagePanel.find('.loader').css("display","inline-block");

        $jQu.ajax({
		   method: "POST",
		   url: adminAjax,
		   crossDomain: true,
		   data: data,
		   cache: false,
		   dataType: 'json',
		   processData: false, // Don't process the files
		   contentType: false
		}).done(function (response) {
            thisImagePanel.find('.loader').hide();
		    var res = eval(response);
		    if (res.success != "undefined" && res.success == 1) {
			   thisImagePanel.find('.image_upload').hide();
               thisImagePanel.find('.thumbnail_view').show();
               thisImagePanel.find('.image_view').empty().append('<img src="'+res.url+'"/><a title="Delete Image" href="#" class="close">×</a>');
               thisImagePanel.find("input[name^=file_name]").val(res.url);
               form.validator('update');
		   }
		   else {
                thisImagePanel.find("span[id^=alertImageMsg]").removeClass('alert-warning').removeClass('alert-success');
                thisImagePanel.find("span[id^=alertImageMsg]").addClass("alert-warning").html(res.message);
		   }
		});
  });
$jQu(document).on('click', '.image_view a.close', function(e) {
	var form            =$jQu(this).closest("form");
    var thisImagePanel  =$jQu(this).parents('.image_panel');
	var file_name       =thisImagePanel.find("input[name^=file_name]").val();
    var old_file_name   =thisImagePanel.find("input[name^=old_file_name]").val();
	var operation       = $jQu('#case').val();
    var id              = "";
    if($jQu('#id'))
    {
        id=$jQu('#id').val();
    }
    if(id!="" && id>0 && file_name==old_file_name)
    {
        thisImagePanel.find('.image_upload').show();
        thisImagePanel.find('.thumbnail_view').hide();
        thisImagePanel.find('.image_view').empty();
        thisImagePanel.find("input[name^=file_name]").val('');
        thisImagePanel.find('span[id^=alertImageMsg]').empty();
        thisImagePanel.find("span[id^=alertImageMsg]").removeClass('alert-warning').removeClass('alert-success');
        thisImagePanel.find('.file-logo').val('');
    }
    else {
        var data = new FormData();
        data.append("action", "lmapp_ajax");
        data.append("task", "save_image");
        data.append("security", window.lmapps_site_nonce);
        data.append("case", operation);
        data.append("delete", true);
        data.append("file_url", file_name);
        thisImagePanel.find('.loader').css("display", "inline-block");
        $jQu.ajax({
            method: "POST",
            url: adminAjax,
            crossDomain: true,
            data: data,
            cache: false,
            dataType: 'json',
            processData: false, // Don't process the files
            contentType: false
        }).done(function (response) {
            thisImagePanel.find('.loader').hide();
            var res = eval(response);
            if (res.success != "undefined" && res.success == 1) {
                thisImagePanel.find('.image_upload').show();
                thisImagePanel.find('.thumbnail_view').hide();
                thisImagePanel.find('.image_view').empty();
                thisImagePanel.find("input[name^=file_name]").val('');
                thisImagePanel.find('span[id^=alertImageMsg]').empty();
                thisImagePanel.find("span[id^=alertImageMsg]").removeClass('alert-warning').removeClass('alert-success');
                thisImagePanel.find('.file-logo').val('');
                form.validator('update');
            }
            else {
                thisImagePanel.find("span[id^=alertImageMsg]").removeClass('alert-warning').removeClass('alert-success');
                thisImagePanel.find("span[id^=alertImageMsg]").addClass("alert-warning").html(res.message);
            }
        });
    }
    return false;
});

/* stripe  Script */
$jQu(document).on('click', 'input[name^="payment_method"], input[name^="payment_option"]', function(e) {
            var inputValue = $jQu(this).attr("value");
            var form_id =$jQu(this).closest("form").attr('id');
            if(inputValue=='Stripe' && inputValue!=''){
				$jQu(".form-stripe").show();
				$jQu(".form-stripe input").attr("required", true);
				$jQu("#".form_id).validator('update');
			}else{
				$jQu(".form-stripe input").attr("required", false);
				$jQu(".form-stripe input").val("");
				$jQu("#".form_id).validator('update');
				$jQu(".form-stripe").hide();
				
				
			}
    });
$jQu(document).on('click', '.favourite_data a', function(e) {
		var id = $jQu(this).attr("data-val");
		var status = $jQu(this).attr("data-status");
		var ftype = $jQu(this).attr("data-type");
		
		if(status==0){
			$jQu("#fv_id"+id).addClass("fv_active");
			$jQu("#fv_id"+id).attr("data-status", "1");
			$jQu("#fv_id"+id).attr("title", "Remove from favourite");
		}else{
			$jQu("#fv_id"+id).removeClass("fv_active");
			$jQu("#fv_id"+id).attr("data-status", "0");
			$jQu("#fv_id"+id).attr("title", "Add to favourite");
		}
        $jQu.ajax({
            method: "POST",
            url: adminAjax,
            data: {
                action: "lmapp_ajax",
                task: "add_to_favourite",
                security: window.lmapps_site_nonce,
                id: id,
                status: status,
                ftype: ftype
            },
            crossDomain: true,
            dataType: 'json'
        }).done(function (response) {
            var res = eval(response);
            
            if (res.success != "undefined" && res.success == 1) {
				if(res.cookie_value === null) {
					Cookies.remove(res.cookie_name);
                 }else{
				 Cookies.set(res.cookie_name, res.cookie_value, { expires: 365 * 10 });	
				}
				
            }
        }).fail(function (response) {
            var res = eval(response.responseJSON);
            if (res.success != "undefined" && res.success == 0) {
                warningMessage(res.message);
            }
        });
 
		return false;
});
function printPartOfPage(elementId) {
        var printContent = document.getElementById(elementId);
        var windowUrl = 'Coupon';
        var uniqueName = new Date();
        var windowName = 'Print' + uniqueName.getTime();
        var header_content ='<div id="headerSection"><img width="240" height="68" src="'+siteLogoUrl+'"></div>';
        var footer = '<div id="footerSection" > Copyright  2017 www.lmappsmt.com.  All rights reserved.</div>';
        var printWindow = window.open(windowUrl, windowName, '');
        printWindow.document.write("<html>");
        var style="<style ='text/css'>";
        style +="@media print{#headerSection, .row-striped{-webkit-print-color-adjust: exact; } #footerSection{ display: block;    width:100%;position:absolute;left:0;bottom:0;text-align:center}}#headerSection{padding: 0px; background-color:#000!important; width:100%; float:left; margin-bottom: 10px;}#headerSection:before {content: '';display: block;position: absolute;top: 0;right: 0;left: 0;z-index: -1;border-bottom: 80px solid #000;} .row{ width:100%; padding:10px; float:left; } .col-4{ width:25%; float:left;} .col-8{ width: 75%; float:left;} .row-striped{ background-color: #eceeef!important; } .row { position: relative; padding-top: 10px; min-height: 30px;} @supports (-ms-ime-align: auto) {.row-striped:before{ content: ''; position: absolute; top: 0; right: 0; bottom: 0; left: 0; z-index: -1; border: 25px solid #eceeef; border-left-width: 20px; }}";
        style +="</style>";
		printWindow.document.write("<head>");
		printWindow.document.write(style);
		printWindow.document.write("</head>");
		printWindow.document.write("<body>");
        printWindow.document.write(header_content);
        printWindow.document.write(printContent.innerHTML);
        printWindow.document.write(footer);
        printWindow.document.write("</body></html>");
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    }

/* Dismiss membership notic */
$jQu(document).on('click', '.membership_notic span.close', function(e) {
	var id = $jQu(this).attr("data-mid");
	
	if (typeof id != "undefined" && id!='') {
        $jQu.ajax({
            method: "POST",
            url: adminAjax,
            data: {
                action: "lmapp_ajax",
                task: "dismiss_memebership_notice",
                security: window.lmapps_site_nonce,
                id: id
            },
            crossDomain: true,
            dataType: 'json'
        }).done(function (response) {
            var res = eval(response);
            if (typeof res.success != "undefined" && res.success == 1) {
               // successSpecificMessage("alertUserNameMsg",res.message);
               $jQu(".membership_notic").hide();
            }
            
        }).fail(function (response) {
            var res = eval(response.responseJSON);
            if (res.success != "undefined" && res.success == 0) {
                warningMessage(res.message);
            }
        });
    }
    
});
$jQu(document).on('change', '#dob', function(e) {
    var user_dob=$jQu(this).val();
    var today = new Date();
	var birthDate = new Date(user_dob);
	var age = today.getFullYear() - birthDate.getFullYear();
	if(typeof age != "undefined" && age >= 13 && age < 18){
		 $jQu('#termuserage .row').css("display","flex");
	     $jQu("#termuserage input").prop('disabled', false);
	     $jQu('#termuserage input').attr('checked',false);
	   
	}else{
		$jQu("#termuserage input").prop('disabled', true);
		$jQu('#termuserage input').attr('checked',true);
		$jQu("#termuserage .row").hide();
	}
});

$jQu(document).on('change', '#fdob', function(e) {
    var user_dob=$jQu(this).val();
    var today = new Date();
	var birthDate = new Date(user_dob);
	var age = today.getFullYear() - birthDate.getFullYear();
	if(typeof age != "undefined" && age >= 13 && age < 18){
		 $jQu('#ftermuserage .row').css("display","flex");
	     $jQu("#ftermuserage input").prop('disabled', false);
	     $jQu('#ftermuserage input').attr('checked',false);
	   
	}else{
		$jQu("#ftermuserage input").prop('disabled', true);
		$jQu('#ftermuserage input').attr('checked',true);
		$jQu("#ftermuserage .row").hide();
	}
});
