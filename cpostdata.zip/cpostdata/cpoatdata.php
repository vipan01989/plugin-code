<?php
/*
	Plugin Name: CPostdata
	Plugin URI: http://CPostdata.co/
	Description: CPostdata replaces default WordPress search and offers fast, relevant and a better search engine.
	Author: CPostdata 
	Version: 1.0
	Author URI: 
*/
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
$cpdpluginUrl = plugin_dir_url(__FILE__);
$cpdpluginPath = plugin_dir_path(__FILE__);
if(substr($cpdpluginUrl, -1) == "/" || substr($cpdpluginUrl, -1) == "\\" ){
	$cpdpluginUrl  = substr($cpdpluginUrl, 0, strlen($cpdpluginUrl)-1 );
}
if(substr($cpdpluginPath, -1) == "/" || substr($cpdpluginPath, -1) == "\\" ){
	$cpdpluginPath  = substr($cpdpluginPath, 0, strlen($cpdpluginPath)-1 );
}

define("CPD_BASE_URL", $cpdpluginUrl);
define("CPD_ADMIN_URL", get_admin_url().'admin.php?page=cpd');
define("CPD_BASE_PATH", $cpdpluginPath);
define("CPD_PLUGIN_VERSION", "1.0");
define("CPD_SERVER_SUB_FOLDER", '');
define("CPD_TIMEOUT_SECONDS", 30);
define("CPD_FILE", __FILE__);


global $cpdAPIClient;
include_once('library/core.php');
include_once('library/hooks.php');
include_once('library/shortcode.php');
include_once('library/plugin.php');
$cpd_plugin = new cpd_plugin;
